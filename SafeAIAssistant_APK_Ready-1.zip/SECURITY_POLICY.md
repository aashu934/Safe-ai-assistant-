# Safe AI Assistant — Phase 2 Security Policy

## Hard blocked
Banking, UPI/payment, money transfer, OTP, PIN/passwords, card/ATM actions,
SIM/eSIM changes, factory reset, lock/security settings, and credential access.

These are blocked at the server policy layer before any AI-generated action
can reach the Android app.

## Safe actions
Opening selected apps and non-sensitive navigation can execute without a
confirmation prompt.

## Confirmation actions
Actions that could send, publish, modify, or communicate externally require
explicit confirmation before execution.

## API key rule
Provider/API secrets must exist only on the backend. Never ship them inside
the Android APK or source-controlled client code.
