plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.safeassistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.safeassistant"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "1.0"
    }
}
