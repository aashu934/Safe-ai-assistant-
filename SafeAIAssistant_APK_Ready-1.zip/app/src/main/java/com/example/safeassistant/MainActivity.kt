package com.example.safeassistant

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.*
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    companion object {
        // Production backend. HTTPS only.
        private const val BACKEND_URL = "https://safe-ai-assistant-backend.vercel.app"
        private const val VOICE_REQUEST = 1001
    }

    private lateinit var tts: TextToSpeech
    private lateinit var status: TextView
    private lateinit var input: EditText
    private lateinit var runButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
    }

    private fun buildUi() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }

        val title = TextView(this).apply {
            text = "Safe AI Assistant"
            textSize = 28f
        }

        status = TextView(this).apply {
            text = "Safe Mode: ON\nBackend: connected by HTTPS"
            textSize = 16f
            setPadding(0, 24, 0, 24)
        }

        input = EditText(this).apply {
            hint = "Command likho…"
            minLines = 3
        }

        runButton = Button(this).apply { text = "Run Safe Command" }
        val speak = Button(this).apply { text = "🎙 Voice Command" }

        runButton.setOnClickListener { sendCommand(input.text.toString()) }
        speak.setOnClickListener { startVoiceInput() }

        layout.addView(title)
        layout.addView(status)
        layout.addView(input)
        layout.addView(runButton)
        layout.addView(speak)
        setContentView(layout)
    }

    private fun sendCommand(command: String) {
        val clean = command.trim()
        if (clean.isEmpty()) {
            speak("Pehle command bolo ya likho.")
            return
        }

        runButton.isEnabled = false
        status.text = "Backend se security check ho raha hai…"

        thread {
            val result = postCommand(clean)
            runOnUiThread {
                runButton.isEnabled = true
                if (result.error != null) {
                    status.text = "Backend error\n${result.error}"
                    speak("Backend se response nahi mila.")
                    return@runOnUiThread
                }

                handleBackendResponse(clean, result.json!!)
            }
        }
    }

    private fun postCommand(command: String): NetworkResult {
        var connection: HttpURLConnection? = null
        return try {
            val url = URL("$BACKEND_URL/command")
            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 10000
                readTimeout = 15000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Accept", "application/json")
            }

            val body = JSONObject().put("command", command).toString()
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream?.let { BufferedReader(InputStreamReader(it)).use { reader -> reader.readText() } }
                ?: "{}"

            if (code !in 200..299) {
                NetworkResult(null, "HTTP $code")
            } else {
                NetworkResult(JSONObject(response), null)
            }
        } catch (e: Exception) {
            NetworkResult(null, "Network error")
        } finally {
            connection?.disconnect()
        }
    }

    private fun handleBackendResponse(command: String, json: JSONObject) {
        val blocked = json.optString("level") == "blocked" || json.optBoolean("blocked", false)
        if (blocked) {
            status.text = "BLOCKED\n${json.optString("reason", "Sensitive action blocked.")}"
            speak("Ye action Safe Mode mein blocked hai.")
            return
        }

        val action = json.optString("action", "none")
        val requiresConfirmation = json.optBoolean("requiresConfirmation", false) ||
            json.optString("level") == "confirm"

        if (requiresConfirmation) {
            AlertDialogBuilder.show(
                this,
                "Confirmation required",
                "Kya aap ye action allow karna chahte hain?\n\n$command",
                onConfirm = { executeAllowedAction(action) },
                onCancel = {
                    status.text = "Cancelled\nAction execute nahi hua."
                    speak("Action cancel kar diya.")
                }
            )
            return
        }

        executeAllowedAction(action)
    }

    // IMPORTANT: only these explicit actions can reach Android intents.
    // Backend/AI text can never become an arbitrary Intent or shell command.
    private fun executeAllowedAction(action: String) {
        when (action) {
            "open_camera" -> {
                startActivity(Intent("android.media.action.IMAGE_CAPTURE"))
                status.text = "Allowed\nCamera opened."
                speak("Camera khol raha hoon.")
            }
            "open_youtube" -> openUrl("https://www.youtube.com/", "YouTube khol raha hoon.")
            "open_browser" -> openUrl("https://www.google.com/", "Browser khol raha hoon.")
            "open_maps" -> openUrl("https://maps.google.com/", "Maps khol raha hoon.")
            "open_whatsapp" -> openUrl("https://wa.me/", "WhatsApp khol raha hoon.")
            else -> {
                status.text = "Not executed\nAction module is not enabled."
                speak("Ye action abhi enabled nahi hai.")
            }
        }
    }

    private fun openUrl(url: String, message: String) {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        status.text = "Allowed\n$message"
        speak(message)
    }

    private fun startVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Command boliye")
        }
        startActivityForResult(intent, VOICE_REQUEST)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == VOICE_REQUEST && resultCode == RESULT_OK) {
            val command = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!command.isNullOrBlank()) {
                input.setText(command)
                sendCommand(command)
            }
        }
    }

    private fun speak(text: String) {
        status.text = text
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "assistant")
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) tts.language = Locale("hi", "IN")
    }

    override fun onDestroy() {
        tts.shutdown()
        super.onDestroy()
    }

    data class NetworkResult(val json: JSONObject?, val error: String?)
}

private object AlertDialogBuilder {
    fun show(
        activity: Activity,
        title: String,
        message: String,
        onConfirm: () -> Unit,
        onCancel: () -> Unit
    ) {
        android.app.AlertDialog.Builder(activity)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Allow") { _, _ -> onConfirm() }
            .setNegativeButton("Cancel") { _, _ -> onCancel() }
            .setOnCancelListener { onCancel() }
            .show()
    }
}
