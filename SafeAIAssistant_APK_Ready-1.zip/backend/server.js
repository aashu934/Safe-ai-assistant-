const express = require("express");
const app = express();
app.use(express.json());

const PORT = process.env.PORT || 8787;

// Server-side policy. Never put an AI/provider key in the Android APK.
const BLOCKED = [
  "bank", "banking", "upi", "payment", "pay ", "transfer",
  "otp", "password", "pin", "credit card", "debit card", "atm",
  "factory reset", "reset phone", "lock screen", "sim", "esim"
];

function classify(command) {
  const c = String(command || "").toLowerCase().trim();
  if (!c) return { level: "blocked", action: "none", reason: "Empty command" };
  if (BLOCKED.some(x => c.includes(x))) {
    return { level: "blocked", action: "none", reason: "Financial/security action is disabled." };
  }
  if (c.includes("camera")) return { level: "safe", action: "open_camera" };
  if (c.includes("youtube")) return { level: "safe", action: "open_youtube" };
  if (c.includes("chrome") || c.includes("browser")) return { level: "safe", action: "open_browser" };
  if (c.includes("maps") || c.includes("map")) return { level: "safe", action: "open_maps" };
  if (c.includes("whatsapp")) return { level: "confirm", action: "open_whatsapp" };
  return { level: "confirm", action: "unmapped", reason: "No safe action module is enabled yet." };
}

app.get("/health", (_, res) => res.json({ ok: true, safeMode: true }));

app.post("/command", (req, res) => {
  const result = classify(req.body?.command);
  res.json({
    assistant: "Safe AI Assistant",
    safeMode: true,
    policyVersion: "1.0",
    ...result
  });
});

app.listen(PORT, () => console.log(`Safe Assistant backend listening on ${PORT}`));
