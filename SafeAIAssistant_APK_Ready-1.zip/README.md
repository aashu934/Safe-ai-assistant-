# Safe AI Assistant — APK Ready

This version connects the Android client to the deployed security gateway:

https://safe-ai-assistant-backend.vercel.app

## Included
- Hindi voice command input
- Text commands
- HTTPS-only backend communication
- Server-side security decision before Android actions
- Confirmation dialog for confirmation-level actions
- Explicit allowlist for Android actions
- No OpenAI API key in the APK
- Banking/payment/OTP/PIN/password/card/ATM/SIM/eSIM/factory-reset/security-setting actions are not implemented

## Build in Android Studio
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Select `app`.
4. Build > Build APK(s).
5. Install the generated debug APK on the Android phone.

The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compileSdk 35 and minSdk 26.

## Important
The backend currently performs a deterministic security classification. It is not yet an OpenAI-powered natural-language brain. OpenAI integration should be added server-side later, with the same independent allowlist/hard-block policy enforced before any Android action.
